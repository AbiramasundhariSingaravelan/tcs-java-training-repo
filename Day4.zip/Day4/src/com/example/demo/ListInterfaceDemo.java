package com.example.demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListInterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> studList=new ArrayList<String>();
		studList.add("Arthi");
		studList.add("Abinaya");
		studList.add("Sahana");
		studList.add("Devasena");
		studList.add("Sanjana");
		studList.add("demo");
		//First Method
		System.out.println(studList);
		//Second Method
		System.out.println("METHOD 2");
		for(String s : studList )
		{
			System.out.println(s);
		}
		//Removing an element
		studList.remove(5);
		//Change the element
		studList.set(4, "Bhavana");
		//Third Method
		System.out.println("METHOD 3");
		Iterator itr=studList.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}

}
