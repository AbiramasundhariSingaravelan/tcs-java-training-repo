import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		int arr[]=new int[5];
		Scanner s=new Scanner(System.in);
		try
		{
			System.out.println("Enter value for A:");
			a=s.nextInt();
			System.out.println("Enter value for B:");
			b=s.nextInt();
			System.out.println("Enter array Value");
			for(int i=0;i<=5;i++)
			{
				arr[i]=s.nextInt();
			}
			if(b==0)
				throw new ArithmeticException("Cannot Divide By Zero");
			else
				c=a/b;
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Size of array is exceeding");
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter a valid input");
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
