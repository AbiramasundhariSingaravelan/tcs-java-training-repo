

class Car
{
	public void print()
	{
		
	}
}
class Accelarator
{
	public void print()
	{
		
	}
}
class SpeedPerKm extends Car, Accelarator
{
	
}
public class Multiple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
