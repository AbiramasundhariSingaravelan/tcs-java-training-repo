import java.util.Scanner;

public class Hello {

	 
	public static void main(String[] args)
	{
		int a;
		System.out.println("Enter the value:");
		//Object Creation
	//	Scanner s=new Scanner(System.in);
		//a=s.nextInt();
		System.out.println("Hello World! Entered Value: " +a);
	}
}
