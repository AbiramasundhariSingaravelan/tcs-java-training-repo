
class A
{
	public void printData()
	{
		System.out.println("Base Class Method");
	}
}
class B extends A
{
	public void printData()
	{
		System.out.println("Base Class Method");
	}
}
class C extends B
{
	public void printData()
	{
		System.out.println("Base Class Method");
	}
}
class D extends C
{
	
}
public class MultilevelDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
