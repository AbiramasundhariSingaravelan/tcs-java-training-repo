 class Demo<T>
 {
	 
 }
public class StringBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder("Hello");
		//sb.append(" to Java");
		//sb.insert(8, "to");
		//sb.insert(10, " ");
		//sb.replace(1,3,"JAVA");
		sb.reverse();
		System.out.println(sb);
		
	}

}
